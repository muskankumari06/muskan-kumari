# Duo-Studio-Clone
Clone of Duo Studio Website

There are some minor bugs that I don't currently know how to fix and the website isn't responsive yet cause I don't know how to make it responsive. 
Taking one step at a time.
